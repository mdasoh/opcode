  /* REG_EVEX_0F71 */
  {
    { Bad_Opcode },
    { Bad_Opcode },
    { PREFIX_TABLE (PREFIX_EVEX_0F71_REG_2) },
    { Bad_Opcode },
    { PREFIX_TABLE (PREFIX_EVEX_0F71_REG_4) },
    { Bad_Opcode },
    { PREFIX_TABLE (PREFIX_EVEX_0F71_REG_6) },
  },
  /* REG_EVEX_0F72 */
  {
    { PREFIX_TABLE (PREFIX_EVEX_0F72_REG_0) },
    { PREFIX_TABLE (PREFIX_EVEX_0F72_REG_1) },
    { PREFIX_TABLE (PREFIX_EVEX_0F72_REG_2) },
    { Bad_Opcode },
    { PREFIX_TABLE (PREFIX_EVEX_0F72_REG_4) },
    { Bad_Opcode },
    { PREFIX_TABLE (PREFIX_EVEX_0F72_REG_6) },
  },
  /* REG_EVEX_0F73 */
  {
    { Bad_Opcode },
    { Bad_Opcode },
    { PREFIX_TABLE (PREFIX_EVEX_0F73_REG_2) },
    { PREFIX_TABLE (PREFIX_EVEX_0F73_REG_3) },
    { Bad_Opcode },
    { Bad_Opcode },
    { PREFIX_TABLE (PREFIX_EVEX_0F73_REG_6) },
    { PREFIX_TABLE (PREFIX_EVEX_0F73_REG_7) },
  },
  /* REG_EVEX_0F38C6 */
  {
    { Bad_Opcode },
    { MOD_TABLE (MOD_EVEX_0F38C6_REG_1) },
    { MOD_TABLE (MOD_EVEX_0F38C6_REG_2) },
    { Bad_Opcode },
    { Bad_Opcode },
    { MOD_TABLE (MOD_EVEX_0F38C6_REG_5) },
    { MOD_TABLE (MOD_EVEX_0F38C6_REG_6) },
  },
  /* REG_EVEX_0F38C7 */
  {
    { Bad_Opcode },
    { MOD_TABLE (MOD_EVEX_0F38C7_REG_1) },
    { MOD_TABLE (MOD_EVEX_0F38C7_REG_2) },
    { Bad_Opcode },
    { Bad_Opcode },
    { MOD_TABLE (MOD_EVEX_0F38C7_REG_5) },
    { MOD_TABLE (MOD_EVEX_0F38C7_REG_6) },
  },
